document.addEventListener("DOMContentLoaded", function() {
    console.log("Website loaded successfully!");
});

document.addEventListener("DOMContentLoaded", function() {
    let buttons = document.querySelectorAll(".view-all-products");
    if (buttons.length > 1) {
        for (let i = 1; i < buttons.length; i++) {
            buttons[i].remove(); 
        }
    }
});

function toggleMenu() {
    document.querySelector("nav ul").classList.toggle("active");
}
// Add to Cart Functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(name, price, image) {
    const existingItem = cart.find(item => item.name === name);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            name: name,
            price: price,
            image: image,
            quantity: 1
        });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCounter();
    showNotification();
}

function updateCartCounter() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCounter').textContent = count;
}

// Initial cart counter update
updateCartCounter();
